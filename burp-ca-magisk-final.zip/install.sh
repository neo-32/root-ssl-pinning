#!/system/bin/sh
SKIPUNZIP=1
ui_print "[*] Installing Burp Suite CA certificate..."
unzip -o "$ZIPFILE" 'system/etc/security/cacerts/9a5ba575.0' -d $MODPATH >&2
chmod 644 "$MODPATH/system/etc/security/cacerts/9a5ba575.0"
chown 0:0 "$MODPATH/system/etc/security/cacerts/9a5ba575.0"
ui_print "[*] Burp CA certificate installed to system trust store."
